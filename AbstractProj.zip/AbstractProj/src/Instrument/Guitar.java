package Instrument;

public class Guitar extends Instrument {

	@Override
	public void play() {
		// TODO Auto-generated method stub
		
	}

}
