package Instrument;

public abstract class Instrument {
	public abstract void play();
}
