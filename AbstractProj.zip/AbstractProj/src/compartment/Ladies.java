package compartment;

public class Ladies extends Compartment {

	@Override
	public void notice() {
		System.out.println("Notice: You're in Ladies");
	}

}
