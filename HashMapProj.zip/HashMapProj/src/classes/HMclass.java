package classes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class HMclass {

	public static void main(String[] args) {
		CountryMap countryMap = new CountryMap();

		countryMap.saveCountryCapital("India", "Delhi");
		countryMap.saveCountryCapital("Japan", "Tokyo");
		countryMap.saveCountryCapital("USA", "Washington, D.C.");

		System.out.println(countryMap.getCapital("India"));
		System.out.println(countryMap.getCountry("Tokyo"));
		System.out.println(countryMap.toArrayList());

		HashMap<String, String> M2 = countryMap.SwapKeysValue();
		System.out.println(M2);
	}
}

class CountryMap {

	static Map<String, String> M1 = new HashMap<String, String>();

	HashMap<String, String> saveCountryCapital(String CountryName, String capital) {
		M1.put(CountryName, capital);
		return (HashMap<String, String>) M1;
	}

	String getCapital(String CountryName) {
		// returns the capital of the country
		String value = M1.get(CountryName);

		return value;

	}

	String getCountry(String capitalName) {
		String capital = " ";
		for (Entry<String, String> entry : M1.entrySet()) {
			if (entry.getValue().equals(capitalName)) {
				capital = entry.getKey();
			}
		}
		return capital;
	}

	HashMap<String, String> SwapKeysValue() {
		Map<String, String> M2 = new HashMap<String, String>();
		Iterator<String> it = M1.keySet().iterator();

		while (it.hasNext()) {
			String key = it.next();
			M2.put(M1.get(key), it.next());
		}
		return (HashMap<String, String>) M2;
	}

	public ArrayList<String> toArrayList() {
		ArrayList<String> list = new ArrayList<>();

		Set<Entry<String, String>> set = M1.entrySet();
		Iterator<Entry<String, String>> it = set.iterator();

		while (it.hasNext()) {
			Map.Entry<String, String> me = it.next();
			list.add(me.getKey());
		}

		return list;
	}
}
